'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _Popover = require('./Popover');

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_Popover).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }