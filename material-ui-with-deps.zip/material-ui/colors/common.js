'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var common = {
  black: '#000',
  white: '#fff'
};

exports.default = common;