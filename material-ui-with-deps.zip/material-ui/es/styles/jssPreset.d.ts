import { JSSOptions } from 'jss';

export default function jssPreset(): JSSOptions;
