export default function unwrap(element: React.ReactElement<any>): React.ReactElement<any>;
