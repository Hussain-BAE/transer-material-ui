export { default } from './Tabs';
export * from './Tabs';
export { default as Tab } from './Tab';
export * from './Tab';
