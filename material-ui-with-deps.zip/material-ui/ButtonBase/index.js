'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ButtonBase = require('./ButtonBase');

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_ButtonBase).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }